using System.IO;
using System.Reflection;

public class Util
{
    public static string GetData()
    {
        StreamReader sr = new StreamReader("data.txt");
        string data = sr.ReadToEnd();
        sr.Close();
        return data;
    }
}
