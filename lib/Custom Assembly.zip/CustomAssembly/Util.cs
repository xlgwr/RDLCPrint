using System.IO;
using System.Reflection;

public class Util
{
    public static int Factorial(int n)
    {
        return ((n <= 1) ? 1 : (n * Factorial(n - 1))); 
    }
}
