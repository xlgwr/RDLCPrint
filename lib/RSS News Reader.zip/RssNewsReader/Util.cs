using System;
using System.Collections.Generic;
using System.Text;

namespace RssNewsReader
{
    public class Util
    {
        public static string StripHtmlTags(string input)
        {
            if (string.IsNullOrEmpty(input))
                return "";
            StringBuilder buffer = new StringBuilder();
            bool insideTag = false;
            for (int i = 0; i < input.Length; i++)
            {
                switch (input[i])
                {
                    case '<':
                        insideTag = true;
                        break;
                    case '>':
                        insideTag = false;
                        break;
                    default:
                        if (!insideTag)
                            buffer.Append(input[i]);
                        break;
                }
            }
            return buffer.ToString();
        }
    }
}
